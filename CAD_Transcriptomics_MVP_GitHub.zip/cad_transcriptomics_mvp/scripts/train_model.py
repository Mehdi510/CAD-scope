"""
Train a transparent baseline CAD classifier from an expression matrix.

Usage:
  python scripts/train_model.py --expression data/expression.csv --metadata data/metadata.csv --out models/cad_model.joblib

Expression format:
  rows = samples, columns = gene symbols
  OR rows = genes with a column named Gene/Gene_ID/Symbol.

Metadata:
  must contain a CAD/control label column named one of:
  CAD, label, status, group, phenotype, class
  and optionally Sample/Sample_ID to align samples.
"""
import argparse, joblib, pandas as pd, numpy as np
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_score

SIGNATURE = [
    "IL6","IL1B","TNF","CXCL8","CCL2","ICAM1","VCAM1","SELE","NFKB1",
    "NFKBIA","STAT3","JUN","FOS","EGR1","EGR3","CCL5","CCR7","CD3D",
    "CD3E","CD4","CD8A","FOXP3","GZMB","MMP9","MMP2","TLR4","SOD2",
    "HMOX1","NOS2","ABCA1","LDLR","APOE","LPL","PPARG","TGFB1"
]

def load_expression(path):
    df = pd.read_csv(path)
    candidates = [c for c in df.columns if str(c).lower() in
                  {"gene","gene_id","geneid","symbol","gene_symbol","genes"}]
    if candidates:
        df = df.set_index(candidates[0]).apply(pd.to_numeric, errors="coerce")
        return df.T
    return df.select_dtypes(include=np.number)

def load_labels(path, samples):
    m = pd.read_csv(path)
    cols = {str(c).lower():c for c in m.columns}
    label_col = next((cols[k] for k in ["cad","label","status","group","phenotype","class"] if k in cols), None)
    sample_col = next((cols[k] for k in ["sample","sample_id","sampleid","id"] if k in cols), None)
    if not label_col:
        raise ValueError("No label column found.")
    if sample_col:
        s = m.set_index(sample_col)[label_col].reindex(samples)
    else:
        s = m[label_col]
        s.index = samples
    mapping = {"cad":1,"case":1,"disease":1,"1":1,"yes":1,"true":1,
               "control":0,"ctrl":0,"normal":0,"healthy":0,"0":0,"no":0,"false":0}
    y = s.astype(str).str.lower().str.strip().map(mapping)
    if y.isna().any():
        y = pd.to_numeric(s, errors="coerce")
    if y.isna().any() or not set(y.unique()).issubset({0,1}):
        raise ValueError("Labels must be binary CAD/control.")
    return y.astype(int)

ap = argparse.ArgumentParser()
ap.add_argument("--expression", required=True)
ap.add_argument("--metadata", required=True)
ap.add_argument("--out", default="models/cad_model.joblib")
args = ap.parse_args()

X = load_expression(args.expression)
X = X.apply(pd.to_numeric, errors="coerce")
X = X.loc[:, X.nunique(dropna=True) > 1]
genes = [g for g in SIGNATURE if g in X.columns]
if len(genes) < 5:
    raise ValueError(f"Only {len(genes)} signature genes found; need at least 5.")
y = load_labels(args.metadata, X.index)

model = Pipeline([
    ("imputer", SimpleImputer(strategy="median")),
    ("scale", StandardScaler()),
    ("clf", LogisticRegression(max_iter=3000, class_weight="balanced"))
])
cv = StratifiedKFold(n_splits=min(5, int(y.value_counts().min())), shuffle=True, random_state=42)
auc = cross_val_score(model, X[genes], y, cv=cv, scoring="roc_auc")
print(f"CV AUROC: {auc.mean():.3f} +/- {auc.std():.3f}")
model.fit(X[genes], y)
joblib.dump({"model": model, "genes": genes}, args.out)
print(f"Saved {args.out}")

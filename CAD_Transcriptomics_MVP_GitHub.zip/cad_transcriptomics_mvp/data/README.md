Place downloaded GEO expression matrices here. Do not commit large patient-level datasets or controlled-access raw sequence data.

Recommended public cohorts:
- GSE180081
- GSE180082
- GSE221911
